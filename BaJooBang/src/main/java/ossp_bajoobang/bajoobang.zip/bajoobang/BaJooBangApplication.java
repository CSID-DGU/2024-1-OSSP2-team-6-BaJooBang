package ossp_bajoobang.bajoobang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaJooBangApplication {

    public static void main(String[] args) {
        SpringApplication.run(BaJooBangApplication.class, args);
    }

}
